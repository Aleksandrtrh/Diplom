
<!-- Модальное окно -->
<div id="registrationModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h2>Регистрация</h2>
        <form id="registrationForm">
            <label for="username">Имя пользователя:</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Электронная почта:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>
</div>

<script>
    // Открытие модального окна
    const modal = document.getElementById("registrationModal");
    const btn = document.getElementById("openModal");
    const span = document.getElementById("closeModal");

    btn.onclick = function() {
        modal.style.display = "block";
    }

    // Закрытие модального окна
    span.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Обработка отправки формы
    document.getElementById('registrationForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Предотвращаем стандартное поведение формы

        // Получаем значения полей
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        // Создаем объект данных для отправки
        const data = {
            username: username,
            email: email,
            password: password
        };

        // Отправляем POST-запрос
        fetch('https://example.com/api/register', { // Замените URL на ваш
            method: 'POST',
            headers: {
                'Content-Type': 'application/json' // Указываем тип контента
            },
            body: JSON.stringify(data) // Преобразуем объект в JSON
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Сеть ответила с ошибкой: ' + response.status);
            }
            return response.json(); // Преобразуем ответ в JSON
        })
        .then(data => {
            console.log('Успех:', data);
            // Закрываем модальное окно после успешной регистрации
            modal.style.display = "none";
            // Здесь можно добавить уведомление об успешной регистрации
        })
        .catch((error) => {
            console.error('Ошибка:', error);
            // Обработка ошибок
        });
    });
</script>

</body>
</html>

Найти еще