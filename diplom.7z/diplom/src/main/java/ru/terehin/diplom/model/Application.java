package ru.terehin.diplom.model;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Table(name = "orders")
public class Application {

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String firstName;

    @Column
    private String lastName;

    @Column
    private String numberPhone;

    @Column
    private String brandCar;

    @Column
    private String modelCar;

    @Column
    private String colorCar;

    @Column
    private Integer mileageCar;

    @ManyToOne
    @JoinColumn (name = "user_id")
    private User user;

    public Application(String firstName, String lastName, String numberPhone, String brandCar, String modelCar, String colorCar, Integer mileageCar) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.numberPhone = numberPhone;
        this.brandCar = brandCar;
        this.modelCar = modelCar;
        this.colorCar = colorCar;
        this.mileageCar = mileageCar;
    }
}
