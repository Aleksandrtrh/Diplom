package ru.terehin.diplom.service;

import org.springframework.stereotype.Service;
import ru.terehin.diplom.model.User;

@Service
public interface UserService {
    User save (User user);
}
