package ru.terehin.diplom.controller.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.terehin.diplom.model.Role;
import ru.terehin.diplom.model.User;
import ru.terehin.diplom.repo.RoleRepo;
import ru.terehin.diplom.service.UserService;

@RestController
@RequiredArgsConstructor
@RequestMapping ("/user")
public class UserController {
    private final UserService userService;
 private final RoleRepo roleRepo;

    @PostMapping
    public void createUser(@RequestBody User user){
        userService.save(user);
    }








}
