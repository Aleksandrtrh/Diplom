package ru.terehin.diplom.service;

import org.springframework.stereotype.Service;
import ru.terehin.diplom.model.Application;
import ru.terehin.diplom.model.User;

@Service
public interface ApplicationService {

    Application save (Application application);

}
