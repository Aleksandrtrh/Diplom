package ru.terehin.diplom.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import ru.terehin.diplom.model.Role;
import ru.terehin.diplom.model.User;
import ru.terehin.diplom.repo.RoleRepo;
import ru.terehin.diplom.repo.UserRepo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepo userRepo;

    private final RoleRepo roleRepo;

    private final PasswordEncoder passwordEncoder;



    public User findByLogin(String name) {
        Optional<User> user = userRepo.findByLogin(name);
        User user1 = user.get();
        return user1;
    }


    @Override
    public User save (User user) {
//        user.getApplications().forEach((el) -> el.setUser(user));
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRoles(List.of(roleRepo.findByLogin("ROLE_USER").get()));
        User newUser = userRepo.save(user);

        return newUser;
    }
}
