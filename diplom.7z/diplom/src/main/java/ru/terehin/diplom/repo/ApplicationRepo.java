package ru.terehin.diplom.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.terehin.diplom.model.Application;

@Repository
public interface ApplicationRepo extends JpaRepository <Application, Long> {
}
