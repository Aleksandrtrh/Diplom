package ru.terehin.diplom.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.terehin.diplom.model.Application;
import ru.terehin.diplom.model.User;
import ru.terehin.diplom.repo.ApplicationRepo;

@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepo applicationRepo;

    @Override
    public Application save(Application application) {
        Application newApplication = applicationRepo.save(application);

        return newApplication;
    }
}
