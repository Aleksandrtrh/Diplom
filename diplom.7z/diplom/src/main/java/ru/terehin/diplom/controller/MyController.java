package ru.terehin.diplom.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import ru.terehin.diplom.service.ApplicationService;
import ru.terehin.diplom.service.UserService;

@Controller
@RequiredArgsConstructor
public class MyController {
    private final UserService userService;

    private final ApplicationService applicationService;

    @GetMapping
    public String getMain() {
        System.err.println(123312);
        return "Avto";
    }

    @GetMapping ("/application")
    public String getObr() {
        System.err.println(125);
        return "Application";
    }


}
