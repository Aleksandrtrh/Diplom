package ru.terehin.diplom.controller.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.terehin.diplom.model.Application;
import ru.terehin.diplom.service.ApplicationService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/application")
public class ApplicationController {
        private final ApplicationService applicationService;


        @PostMapping
        public void createapplication (@RequestBody Application application){
            applicationService.save(application);
        }




}
