package ru.terehin.diplom.model;


import jakarta.persistence.*;
import lombok.*;

import java.util.Collection;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table (name = "users")

@EqualsAndHashCode
@ToString
public class User {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String login;

    @Column
    private String password;


    @ManyToMany
    @JoinTable (
            name = "user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")

    )
    private Collection<Role> roles;

    // TODO что такое mappedBy
    @OneToMany (cascade = CascadeType.ALL, mappedBy = "user")
    private List <Application> applications;


    public User(String login, String password, List<Application> applications) {
        this.login = login;
        this.password = password;
        this.applications = applications;
    }
}
