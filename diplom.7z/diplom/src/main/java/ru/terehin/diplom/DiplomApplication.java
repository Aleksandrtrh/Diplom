package ru.terehin.diplom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.terehin.diplom.model.Role;


// http://localhost:8080
// insert into roles ("id", login) values (1, 'ROLE_LOGIN')
//insert into roles ("id", login) values (1, 'ROLE_USER')
@SpringBootApplication
public class DiplomApplication {



	public static void main(String[] args) {
		SpringApplication.run(DiplomApplication.class, args);

	}

}
